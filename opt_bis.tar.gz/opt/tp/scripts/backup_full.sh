#!/bin/bash
touch /var/log/backup.log # Creacion de archivo log
> /var/log/backup.log #Se vacia el archivo log
for arg in "$@"
do
    if [ "$arg" == "--help"  ] || [ "$arg" == "-h" ]; # Si en el argumento colocamos -h o --help nos muestra la ayuda
    then
	echo "Este script ejecutará el backup de los directorios /etc y /var/log automaticamente todos los dias a las 00hs. Ademas ejecutará el backup de los directorios /u01 y /u02 todos los domingos a las 23hs."
	echo""
	echo "Al colocar ./backup_full.sh /etc /var/log /u03 se realiza el primer backup."
	echo""
	echo "Al colocar ./backup_full.sh /u01 /u02 /u03 se realiza el segundo backup."
	echo""
	echo "En caso de errores, se enviarán mails a root, en la casilla mutt."
    fi
done

#Declaracion de argumentos

DIR_ORIGEN=$1
DIR_ORIGEN_2=$2
DIR_DESTINO=$3
if [ "$1" == "/etc" ] && [ "$2" == "/var/log" ] && [ "$3" == "/u03" ]; #Verificacion de argumentos de entrada
then

#Backup1
      FECHA=`date +%Y%m%d`                    # Fecha de ejecuccion
      NOM_ARCHIVO=etc_bkp_$FECHA.tar.gz       # Nombre del arCHIVO 
      if [ -d "$1" ] && [ -d "$3" ];          #Verifica. Si es verdadero, realiza backup
      then
      	tar -cpzf $3/$NOM_ARCHIVO $1 
        echo "`date +%H:%M:%S` Se realizó el Backup de etc" >> /var/log/backup.log              
       else
        echo "`date +%H:%M:%S` No se encuentra el directorio /etc" >> /var/log/backup.log
       fi

#Backup2
      FECHA=`date +%Y%m%d`                        #Fecha de ejecuccion
      NOM_ARCHIVO=var_log_bkp_$FECHA.tar.gz       #Nombre del archivo
      if [ -d "$2" ] && [ -d "$3" ]; #Verifica. Si es verdadero , realiza backup
      then
   	   tar -cpzf $3/$NOM_ARCHIVO $2
      	   echo "`date +%H:%M:%S` Se realizó el backup de var/log" >> /var/log/backup.log
      else
            echo "`date +%H:%M:%S` No se encuentra el directorio /var/log" >> /var/log/backup.log
      fi
mutt -s "Reporte Backup" root@debian.up < /var/log/backup.log #El reporte es enviado via mail
fi


if [ "$1" == "/u01" ] && [ "$2" == "/u02" ] && [ "$3" == "/u03" ]; #Verificacion de arguementos de entrada
then

#Backup3
      FECHA=`date +%Y%m%d`                    # Fecha de ejecuccion
      NOM_ARCHIVO=u01_bkp_$FECHA.tar.gz       # Nombre del archivo
      if [ -d "$1" ] && [ -d "$3" ]; #Verifica. Si dichos directorios dados por argumento son validos
      then
      	tar -cpzf $3/$NOM_ARCHIVO $1
        echo "`date +%H:%M:%S` Se realizó el Backup de /u01" >> /var/log/backup.log              
       else
        echo "`date +%H:%M:%S` No se encuentra el directorio /u01" >> /var/log/backup.log
       fi
 
#Backup4
      FECHA=`date +%Y%m%d`                        #Fecha de ejecuccion
      NOM_ARCHIVO=u02_bkp_$FECHA.tar.gz           #Nombre del archivo
      if [ -d "$2" ] && [ -d "$3" ]; #Verifca. Si dichos directorios dados por argumentos son validos.
      then
   	   tar -cpzf $3/$NOM_ARCHIVO $2
      	   echo "`date +%H:%M:%S` Se realizó el backup de /u02" >> /var/log/backup.log
      else
            echo "`date +%H:%M:%S` No se encuentra el directorio /u02" >> /var/log/backup.log
      fi
mutt -s "Reporte Backup" root@debian.up < /var/log/backup.log #El reporte es enviado por mail
fi
