#!/bin/bash

#Argumentos

SERVICIO_1=$1
SERVICIO_2=$2
SERVICIO_3=$3

#Dado un argumento como servicio, se invoca a las siguientes lineas de comandos para saber si el servicio esta activo o no.


ESTADO1="$(systemctl is-active $SERVICIO_1.service)" 

ESTADO2="$(systemctl is-active $SERVICIO_2.service)"

ESTADO3="$(systemctl is-active $SERVICIO_3.service)"

#Si no esta activo, envia un mensaje via mail local diciendo que el servidor no esta disponible.

if [ "$ESTADO1" != "active" ]; then   
 echo "El servidor Apache2 no está activo" | mutt -s "Reporte Apache2" root@debian.up
fi

if [ "$ESTADO2" != "active" ]; then
  
 echo "El servidor SSH no está activo" | mutt -s "Reporte SSH" root@debian.up
fi

if [ "$ESTADO3" != "active" ]; then
 echo "El servidor MYSQL no está activo" | mutt -s "Reporte Mysql" root@debian.up
fi
